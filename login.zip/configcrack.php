<?php

$logindata = array(
	// buat Login ke halaman admin
	'email'		=>	'admin@memekcorp.xyz',
	'passw'		=>	'memekcorp'
);