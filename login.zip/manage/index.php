<?php
include('index.inc.php');
//include 'load.php';
//valid_file("v2/apps/index.php");
?>
<a style="display:none" href="trap">Do not go here</a>