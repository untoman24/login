1)make sure your cpanel php 7 and curl are active.
  
2) upload your scampage

3) make sure your all your scampage file on /public.html

4) on your browser call https://your domain.com/safelink.php

   enter email pass to login to scam password enter this;

   admin@memekcorp.xyz
   memekcorp 

5) on admin panel click setting put your mail. or replace with your mail.don't touch anything if you don't know how to setting only change
   mail or replace with your mail.click save.

6) after that put  or replace https link on urlsafe.php file, with your https://yourdomain/?neo  remember should use ?neo.

7) call your scampage https://your domain/urlsafe.php

8)done happy spaming


