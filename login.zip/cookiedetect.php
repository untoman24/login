<?php
if (isset($_GET['cookiecheck'])) {
    if (isset($_COOKIE['testcookie'])) 

    {
header('Location:adminasli/');

}
    
    else {
        echo "<script> window.location= 'trap/index.php' </script>";
    }
    
    
    
} else {
    setcookie('testcookie', "testvalue");
    die(header("Location: " . $_SERVER['PHP_SELF'] . "?cookiecheck=1"));
}
?>